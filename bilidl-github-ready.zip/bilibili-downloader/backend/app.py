import os
import re
import tempfile
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import yt_dlp

app = Flask(__name__)
CORS(app)

BILIBILI_HOSTS = {
    "bilibili.com",
    "www.bilibili.com",
    "m.bilibili.com",
    "b23.tv",
    "www.b23.tv",
}

def is_bilibili_url(url: str) -> bool:
    match = re.match(r"^https?://([^/]+)", url.strip().lower())
    if not match:
        return False
    host = match.group(1).split(":")[0]
    return host in BILIBILI_HOSTS or host.endswith(".bilibili.com")

def get_info(url: str):
    options = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
    }

    with yt_dlp.YoutubeDL(options) as ydl:
        return ydl.extract_info(url, download=False)

@app.get("/")
def home():
    return jsonify({
        "service": "BiliDL backend",
        "status": "online"
    })

@app.get("/health")
def health():
    return jsonify({"ok": True})

@app.post("/api/info")
def info():
    data = request.get_json(silent=True) or {}
    url = str(data.get("url", "")).strip()

    if not is_bilibili_url(url):
        return jsonify({"error": "Please enter a valid Bilibili URL."}), 400

    try:
        info_data = get_info(url)

        duration = info_data.get("duration")
        duration_text = None

        if duration:
            minutes = int(duration // 60)
            seconds = int(duration % 60)
            duration_text = f"{minutes}:{seconds:02d}"

        return jsonify({
            "title": info_data.get("title", "Bilibili video"),
            "thumbnail": info_data.get("thumbnail"),
            "duration": duration_text,
        })

    except Exception as exc:
        return jsonify({
            "error": "Could not read this video. It may be private, unavailable, region-restricted, or unsupported.",
            "details": str(exc)
        }), 500

@app.get("/api/download")
def download():
    url = request.args.get("url", "").strip()

    if not is_bilibili_url(url):
        return jsonify({"error": "Invalid Bilibili URL."}), 400

    temp_dir = tempfile.mkdtemp(prefix="bilidl_")
    output_template = os.path.join(temp_dir, "%(title).120s.%(ext)s")

    options = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        # Prefer a single MP4 when available. This avoids requiring ffmpeg
        # for the normal case.
        "format": "best[ext=mp4]/best",
        "outtmpl": output_template,
    }

    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info_data = ydl.extract_info(url, download=True)
            downloaded = ydl.prepare_filename(info_data)

        if not os.path.exists(downloaded):
            files = [
                os.path.join(temp_dir, name)
                for name in os.listdir(temp_dir)
            ]
            if not files:
                raise RuntimeError("Downloaded file was not created.")
            downloaded = files[0]

        filename = os.path.basename(downloaded)

        return send_file(
            downloaded,
            as_attachment=True,
            download_name=filename,
            max_age=0
        )

    except Exception as exc:
        return jsonify({
            "error": "Download failed.",
            "details": str(exc)
        }), 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
